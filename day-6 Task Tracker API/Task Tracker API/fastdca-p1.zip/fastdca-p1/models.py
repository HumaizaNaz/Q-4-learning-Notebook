from typing import List
from schemas import UserRead, Task

users_db: List[UserRead] = []
tasks_db: List[Task] = []
